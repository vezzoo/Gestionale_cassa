This archive contains the complete OpenUI5 runtime. Deploy the content on any web server and load resources/sap-ui-core.js in your web application to use OpenUI5.
Further information can be found at http://openui5.org

OpenUI5 is licensed under the Apache License, Version 2.0 - see LICENSE.txt